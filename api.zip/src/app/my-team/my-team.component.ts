import { Component, OnInit } from '@angular/core';
import { RestApiService } from "../shared/rest-api.service";

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit {
  Team: any = [];
  constructor(
  public restApi: RestApiService
  ) { }
  ngOnInit() {
  this.loadTeams()
  }
  // Get team list
  loadTeams() {
  return this.restApi.getTeams().subscribe((data: {}) => {
  this.Team = data;
  })
  }
  // Delete team
  deleteTeam(id) {
  if (window.confirm('Do you really want to delete team?')){
  this.restApi.deleteTeam(id).subscribe(data => {
  this.loadTeams()
  })
  }
  }  
  }