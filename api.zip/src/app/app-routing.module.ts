import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CrTeamComponent } from './cr-team/cr-team.component';
import { MyTeamComponent } from './my-team/my-team.component';
import { TeamEditComponent } from './team-edit/team-edit.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'cr-team' },
  { path: 'cr-team', component: CrTeamComponent },
  { path: 'team', component: MyTeamComponent },
  { path: 'team-edit', component: TeamEditComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
