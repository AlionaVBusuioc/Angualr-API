export class Team {
    id: string;
    administrator: string;
    description: string;  
}
