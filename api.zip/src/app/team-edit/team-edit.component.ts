import { Component, OnInit } from '@angular/core';
import { RestApiService } from "../shared/rest-api.service";
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-team-edit',
  templateUrl: './team-edit.component.html',
  styleUrls: ['./team-edit.component.css']
})
export class TeamEditComponent implements OnInit {
  id = this.actRoute.snapshot.params['id'];
  teamData: any = {};
  constructor(
  public restApi: RestApiService,
  public actRoute: ActivatedRoute,
  public router: Router
  ) { 
  }
  ngOnInit() { 
  this.restApi.getTeam(this.id).subscribe((data: {}) => {
  this.teamData = data;
  })
  }
  // Update team data
  updateTeam() {
  if(window.confirm('Are you sure, you want to update?')){
  this.restApi.updateTeam(this.id, this.teamData).subscribe(data => {
  this.router.navigate(['/team-list'])
  })
  }
  }
  }