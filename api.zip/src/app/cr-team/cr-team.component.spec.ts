import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrTeamComponent } from './cr-team.component';

describe('CrTeamComponent', () => {
  let component: CrTeamComponent;
  let fixture: ComponentFixture<CrTeamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrTeamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrTeamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
