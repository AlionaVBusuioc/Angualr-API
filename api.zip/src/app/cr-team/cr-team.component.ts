import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from "../shared/rest-api.service";

@Component({
  selector: 'app-cr-team',
  templateUrl: './cr-team.component.html',
  styleUrls: ['./cr-team.component.css']
})
export class CrTeamComponent implements OnInit {
  @Input() teamDetails = { administrator: '', description: ''}
  constructor(
  public restApi: RestApiService, 
  public router: Router
  ) { }
  ngOnInit() { }
  addTeam(dataTeam) {
  this.restApi.createTeam(this.teamDetails).subscribe((data: {}) => {
  this.router.navigate(['/team'])
  })
  }
  }
